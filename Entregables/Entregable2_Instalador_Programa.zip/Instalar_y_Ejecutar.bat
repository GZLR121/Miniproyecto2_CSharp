@echo off
title Sistema de Logistica y Auditoria - Autor: Gael Zair Limon Rdz
echo ====================================================================
echo   SISTEMA DE PROCESAMIENTO Y AUDITORIA DE FACTURACION (WINFORMS)
echo   Autor: Gael Zair Limon Rdz
echo ====================================================================
start "" "%~dp0SistemaLogisticaAuditoria.exe"
